﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementProgram
{
    internal class StudentInfo
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public double Mathh { get; set; }
        public double Physical { get; set; }
        public double Chemical { get; set; }
        public double GPA { get; set; }
        public string Rate { get; set; }
    }
}
